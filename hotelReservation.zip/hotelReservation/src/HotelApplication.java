import static menus.MainMenu.displayMainMenu;

public class HotelApplication {

    public static void main ( String [ ] args ) {

        displayMainMenu ();
    }
}
