package service;

import model.Customers;
import model.IRoom;
import model.Reservation;

import java.util.*;

public class ReservationService {

    public static List <IRoom> allRooms = new ArrayList<>();
    public static List <Reservation> reservationList = new ArrayList<>();
    public static HashMap<String, IRoom>  roomList = new HashMap<>();

    public void addRoom (IRoom room) {

        allRooms.add(room);
}

    public  IRoom getARoom (String roomId) {

        for (int i = 0; i < allRooms.size(); i++) {
            try{
                if (allRooms.get(i).getRoomNumber() == roomId){
                    return allRooms.get(i);
                }
            } catch (ArrayIndexOutOfBoundsException exception) {
                System.out.println("Room does not exist, please choose another room");
            }
        }

        return null;
}

    public Reservation reserveRoom (Customers customers, IRoom rooms, Date checkInDate, Date checkOutDate){

        Reservation reserve = new Reservation(customers, rooms, checkInDate, checkOutDate);
        reservationList.add (reserve);
        return reserve;
    }

    public Collection<IRoom> findRooms(Date checkInDate, Date checkOutDate){
        //find a room that is available for that time-
        //looping through all the rooms- for each room - you are checking reservation within that date
        //if no reservation- you add to the collection, otherwise you just move on
        //new collection of availableRooms
        List<IRoom> availableRooms = new ArrayList<IRoom>();
        if (reservationList.isEmpty())
            return allRooms;
        for (IRoom roomSpace : allRooms){
            for (Reservation revSpace : reservationList){

                if (revSpace.getRoom().equals(roomSpace.getRoomNumber())){
                    if (checkInDate.after(revSpace.getCheckInDate()) && checkInDate.before(revSpace.getCheckOutDate()) ||
                            checkInDate.after(revSpace.getCheckInDate()) && checkInDate.before(revSpace.getCheckOutDate()) ||
                    checkInDate.equals(revSpace.getCheckInDate())||
                            checkOutDate.equals(revSpace.getCheckOutDate())){
                        availableRooms.add(roomSpace);
                    }
                }
                else {
                    availableRooms.add(roomSpace);
                }
            }
        }
        System.out.println("rooms" + availableRooms);
        return availableRooms;
        //ArrayList<IRoom> availableRoomList = new ArrayList<IRoom>();

        /*for (IRoom compareRoom : roomList.values()){
            boolean roomIsBooked = true;

            //look in reservation to see if room is already reserved
            //listOfReservations.checkInDate is between the checkInDate and checkOutDate passed in-
            for(Reservation compareReservation : reservationList) {
                // System.out.println("In for of reservations");
                if (compareReservation.getRoom().getRoomNumber().equals(compareRoom.getRoomNumber())) {
                    if (!checkInDate.after(compareReservation.getCheckInDate()) && !checkInDate.before(compareReservation.getCheckOutDate()) ||
                            (!checkOutDate.after(compareReservation.getCheckInDate()) && !checkOutDate.before(compareReservation.getCheckOutDate())) ||
                            (checkInDate.equals(compareReservation.getCheckInDate()))||
                            (checkOutDate.equals(compareReservation.getCheckOutDate()))
                    )
                        //also checkout date can't fall in between either
                        //room is available
                        // availRoomList.add(compareRoom);
                        roomIsBooked = false;
                    break;
                }
            }
            if (roomIsBooked) {
                availableRoomList.add(compareRoom);
            }

        }
        // System.out.println(roomList);
        return availableRoomList;*/

    }

    //if (checkInDate.after (revSpace.getCheckOutDate ()) || checkOutDate.before
    //(revSpace.getCheckInDate ()))

            public Collection <Reservation> getCustomersReservations (Customers customers) {

        ArrayList <Reservation> resArray = new ArrayList<>();
            for (Reservation revSpace : reservationList) {
                if(revSpace.getCustomers() == customers) {
                    resArray.add(revSpace);
                }
            }
            return resArray;
        }

        public void printAllReservations () {
        for (Reservation reserve : reservationList) {
            System.out.println(reserve);
        }
    }
}





