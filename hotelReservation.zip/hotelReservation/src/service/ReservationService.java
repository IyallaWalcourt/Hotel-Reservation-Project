package service;

import model.Customers;
import model.IRoom;
import model.Reservation;

import java.util.*;

public class ReservationService {

    private static ReservationService INSTANCE;
    private Set<IRoom> rooms = new HashSet<>();
    private Collection<Reservation> reservations = new HashSet<>();

    private ReservationService() {}

    public static ReservationService getINSTANCE() {
        if (INSTANCE == null) {
            synchronized (ReservationService.class) {
                if (INSTANCE == null) {
                    INSTANCE = new ReservationService();
                }
            }
        }

        return INSTANCE;
    }

    public void  addRooms(IRoom room){
        rooms.add(room);
    }

    public IRoom getARoom (String roomID){
        for (IRoom ir : rooms) {
            if (ir.getRoomNumber().equals(roomID)) {
                return ir;
            }
        }
            System.out.printf("there is no room with umber %s, choose another one%n", roomID);
        return null;
    }

    public Reservation reserveARoom(Customers customers, IRoom room, Date checkInDate, Date checkOutDate){
        Reservation reserveForCustomer = new Reservation(customers, room, checkInDate, checkOutDate);
        reservations.add(reserveForCustomer);
        System.out.println("This room has been reserved");
        return reserveForCustomer;
    }

    public ArrayList<Reservation> findRooms(Date checkInDate, Date checkOutDate) {
        Set<IRoom> roomsAvailable  = new HashSet<>();
        System.out.println("Choose from the list of rooms: " + rooms);

        if (reservations.size() == 0){
            roomsAvailable = rooms;
            return  roomsAvailable;
        }else {
            for (Reservation r : reservations) {
                for (IRoom iRoom : rooms) {
                    if ((iRoom.getRoomNumber().equals(r.getRoom().getRoomNumber())) &&

                            ((checkInDate.before(r.getCheckInDate()) && checkOutDate.before(r.getCheckInDate()))
                                    ||

                                    (checkInDate.after(r.getCheckOutDate()) && checkOutDate.after(r.getCheckOutDate())))
                        ||
                            (!r.getRoom().getRoomNumber().contains(iRoom.getRoomNumber()))) {
                        roomsAvailable.add(iRoom);

                    } else if (iRoom.getRoomNumber().equals(r.getRoom().getRoomNumber())) {
                        roomsAvailable.remove(iRoom);
                    }
                }
            }

            public Collection<Reservation> getCustomerReservation (Customers customers) {
                return  getCustomersReservationDefault(customers);
            }

            Collection<Reservation> getCustomerReservationDefault (Customers customers) {
                ArrayList<Reservation> newList = new ArrayList<>();

                for (Reservation res : reservations) {

                    if (res.getCustomers().equals(customers)) {
                        if (res.getCustomers().equals(customers)) {
                    }
                }
                    return newList;
            }
        }
            public Collection<Reservation> getAllReservations () {
                return reservations;
            }

            public Collection<IRoom> getAllRooms () {
                return rooms;
            }
    }

}
