package service;

import model.Customers;
import model.IRoom;
import model.Reservation;

import java.util.*;

public class ReservationService {


    public static ReservationService reservationService = null;

    //default access modifier
     static HashMap<String, IRoom> roomList = new HashMap<>();

    public static ArrayList<Reservation> reservationList = new ArrayList<>();

    private ReservationService() {
    }


    public static ReservationService getInstance() {
        if (null == reservationService) {
            reservationService = new ReservationService();
        }
        return reservationService;
    }

    public void addRoom(IRoom room) {
        roomList.put(room.getRoomNumber(), room);
        System.out.println("room added");

    }

    public IRoom getARoom(String roomId) {

        return (roomList.get(roomId));
    }

    public Reservation reserveARoom(Customers customers, IRoom rooms, Date checkInDate, Date checkOutDate) {

        Reservation reserve = new Reservation(customers, rooms, checkInDate, checkOutDate);
        reservationList.add(reserve);
        return reserve;
    }

    public Collection<IRoom> findRooms(Date checkInDate, Date checkOutDate) {
        //find available rooms

        ArrayList<IRoom> availableRooms = new ArrayList<IRoom>();

        for (IRoom compareRoom : roomList.values()) {
            boolean booked = true;

            for (Reservation compareReservation : reservationList) {
                if (compareReservation.getRoom().getRoomNumber().equals(compareRoom.getRoomNumber())) {
                    if (!checkInDate.after(compareReservation.getCheckInDate()) && !checkInDate.before(compareReservation.getCheckOutDate()) ||
                            (!checkOutDate.after(compareReservation.getCheckInDate()) && !checkOutDate.before(compareReservation.getCheckOutDate())) ||
                            (checkInDate.equals(compareReservation.getCheckInDate())) ||
                            (checkOutDate.equals(compareReservation.getCheckOutDate()))
                    )

                        booked = false;
                    break;
                }
            }
            if (booked) {
                availableRooms.add(compareRoom);
            }

        }

        return availableRooms;

    }

    public Collection<Reservation> getCustomersReservation(Customers customers) {

        ArrayList<Reservation> resArray = new ArrayList<>();
        for (Reservation revSpace : reservationList) {
            if (customers == revSpace.getCustomers()) {
                resArray.add(revSpace);
            }
        }

        if (!resArray.isEmpty()) {
            return resArray;
        }
        else {
            //If no reservation found, print "No Reservation found"
            System.out.println("No Reservation found");
            return null;
        }
    }

    public void printAllReservation(){
        for (Reservation  reserved : reservationList) {
            System.out.println(reserved);
        }

    }

    public Collection<Reservation> getAllReservations() {
        return reservationList;
    }

    public Collection<IRoom> getAllRooms(){

        return roomList.values();
    }


}






