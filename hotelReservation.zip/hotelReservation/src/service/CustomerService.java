package service;

import model.Customers;

import java.util.Collection;
import java.util.HashSet;
import java.util.Optional;

public class CustomerService {

    private static CustomerService customerService = null;
     Collection<Customers> setOfCustomers = new HashSet();

    private CustomerService() {

    }

    public static CustomerService getInstance() {
        if (null == customerService) {
            System.out.println("CUSTOMER SERVICE: NULL");
            customerService = new CustomerService();
        }

        return customerService;

    }

    public void addCustomers(String email, String firstName, String middleName, String lastName) {
        Customers customers = new Customers(firstName, middleName, lastName, email);
        customers.add(customers);
    }

    public Customers getCustomers(String customersEmail) {
        Optional<Customers> customers = customers.stream().filter(c -> customersEmail.equals(c.getEmail())).
        findFirst();
            return customers.orElse(null);

    }

    private void findFirst() {
    }

    public Collection<Customers> getSetOfCustomers() {
        return setOfCustomers;
    }
}
