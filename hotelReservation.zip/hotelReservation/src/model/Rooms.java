package model;

public class Rooms implements IRoom {

    private String roomNumber;
    protected Double roomPrice;
    private RoomType enumeration;

    public Rooms(String roomNumber, RoomType enumeration) {
        this.roomNumber = roomNumber;
        this.enumeration = enumeration;
    }

    public Rooms(String roomNumber, Double roomPrice, RoomType enumeration) {
        super();
        this.roomNumber = roomNumber;
        this.roomPrice = roomPrice;
        this.enumeration = enumeration;
    }

    @Override
    public String getRoomNumber() {
        return roomNumber;
    }

    @Override
    public Double getRoomPrice() {
        return roomPrice;
    }

    @Override
    public RoomType getRoomType() {
        return enumeration;
    }

    @Override
    public boolean isFree() {
        return false;
    }

    @Override
    public String toString() {
        return " Room Number: " + roomNumber + " \nRoom Price: " + roomPrice + " \nRoom Type: " + enumeration + '\n';
    }
}
