package menus;

import api.AdminResource;
import model.RoomType;

import java.util.Scanner;

import static model.RoomType.valueOf;

public class AdminMenu {

    private static final AdminResource adminresource = new AdminResource ();

    public static void displayAdminMenu () {

        Scanner scanner = new Scanner (System.in);
        int userIntput = 0;

        while (userIntput!= 5) {

            printOptions ();
            userIntput = scanner.nextInt ();

            switch (userIntput) {
                case 1:
                    System.out.println (adminresource.getAllCustomers ());
                    break;
                case 2:
                    System.out.println (adminresource.getAllRooms ());
                    break;
                case 3:
                    adminresource.displayAllReservations ();
                    break;
                case 4:
                    case4 ();
                    break;
                case 5:
                    MainMenu.displayMainMenu ();
                    return;
            }
        }
    }

    public static void printOptions () {
        System.out.println ("Admin Menu"
                + "\n1. See all customers"
                + "\n2. See all rooms"
                + "\n3. See all reservations"
                + "\n4. Add a room"
                + "\n5. Back to main menu");
    }

    //add a room
    public static void case4 () {

        Scanner scanner = new Scanner ( System.in );
        System.out.println ("Enter a room number:");
        String roomNumber = scanner.next ();
        System.out.println ( "Enter price per night :");
        Double price = scanner.nextDouble ();
        System.out.println ( "Enter Room type: e.g SINGLE or DOUBLE" );
        RoomType roomType = valueOf (scanner.next ());
        adminresource.makeRoom (roomNumber, price, roomType);
    }
}
