package service;

import model.Customers;
import model.IRoom;
import model.Reservation;

import java.util.*;
import java.util.stream.Collectors;

public class ReservationService {

    private static final int recommended_days = 7;
    public static ReservationService reservationService = null;

    //default access modifier
     static HashMap<String, IRoom> roomList = new HashMap<>();

    //public static ArrayList<Reservation> reservationList = new ArrayList<>();
    private final Map<String, Collection<Reservation>> reservationList = new HashMap<>();

    private ReservationService() {
    }


    public static ReservationService getInstance() {
        if (null == reservationService) {
            reservationService = new ReservationService();
        }
        return reservationService;
    }

    public void addRoom(IRoom room) {
        roomList.put(room.getRoomNumber(), room);
        System.out.println("room added");

    }

    public IRoom getARoom(String roomId) {

        return (roomList.get(roomId));
    }

    public Reservation reserveARoom(Customers customer, IRoom room, Date checkInDate, Date checkOutDate) {

        final Reservation reservation = new Reservation(customer, room, checkInDate, checkOutDate);
        Collection<Reservation> reserved = getCustomersReservation(customer);
        //reservedList.add(reservation);
        if(reserved == null) {
            reserved = new LinkedList<>();
        }
        reserved.add(reservation);
        reservationList.put(customer.getEmail(), reserved);
        return reservation;
    }

    public Collection<IRoom> findRooms(Date checkInDate, Date checkOutDate) {
        //find available rooms

        /*ArrayList<IRoom> availableRooms = new ArrayList<IRoom>();

        for (IRoom compareRoom : roomList.values()) {
            boolean booked = true;

            for (Reservation compareReservation : reservationList) {
                if (compareReservation.getRoom().getRoomNumber().equals(compareRoom.getRoomNumber())) {
                    if (!checkInDate.after(compareReservation.getCheckInDate()) && !checkInDate.before(compareReservation.getCheckOutDate()) ||
                            (!checkOutDate.after(compareReservation.getCheckInDate()) && !checkOutDate.before(compareReservation.getCheckOutDate())) ||
                            (checkInDate.equals(compareReservation.getCheckInDate())) ||
                            (checkOutDate.equals(compareReservation.getCheckOutDate()))
                    )

                        booked = false;
                    break;
                }
            }
            if (booked) {
                availableRooms.add(compareRoom);
            }

        }

        return availableRooms;*/

        return getUnreservedRooms(checkInDate, checkOutDate);

    }

    private Collection<IRoom> getUnreservedRooms(final Date checkIn, final Date checkOut) {

        final Collection<Reservation> allreservations = getAllReservation();
        final Collection<IRoom> reservedRooms = new LinkedList<>();

        for(Reservation reservation : allreservations) {

            //To check reservation dates Overlap
            if (checkIn.before(reservation.getCheckOutDate()) && checkOut.after(reservation.getCheckInDate())) {

                reservedRooms.add(reservation.getRoom());

            }
        }
        return roomList.values().stream().filter(room -> reservedRooms.stream().noneMatch(reservedRoom -> reservedRoom.equals(room))).collect(Collectors.toList());
    }

    public Collection<IRoom> findRecommendedRooms(final Date checkInDate, final Date checkOutDate) {

        return findRooms(addRecommendedDays(checkInDate), addRecommendedDays(checkOutDate));

    }



    public Collection<Reservation> getCustomersReservation (Customers customer) {
        return reservationList.get(customer.getEmail());
    }


    public void printAllReservation() {

        final Collection<Reservation> reservedList = getAllReservation();
        if (reservedList.isEmpty()) {
            System.out.println("No Reservations");
        } else {
            for (Reservation reserved : reservedList) {
                System.out.println(reserved + "\n");
            }
        }
    }

    private Collection<Reservation> getAllReservation() {
        Collection<Reservation> allReservatons = new LinkedList<>();

        for(Collection<Reservation> reserv : reservationList.values()) {
            allReservatons.addAll(reserv);
        }

        return allReservatons;
    }

    public Collection<IRoom> getAllRooms(){

        return roomList.values();
    }

    /*private Collection<Reservation> getAllReservation() {
        Collection<Reservation> allReservatons = new LinkedList<>();

        for(Collection<Reservation> reserv : reservationList.values()) {
            allReservatons.addAll(reserv);
        }

        return allReservatons;
    }*/

    public Date addRecommendedDays(final Date date) {

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DATE, recommended_days);
        return calendar.getTime();
    }



    Date getRecommendedDays(Date date) {
        return addRecommendedDays(date);
    }


}






