package service;

import model.Customers;

import java.util.*;

public class CustomerService {

    private static CustomerService customerService = null;

    private static  ArrayList<Customers> customersList = new ArrayList<>();

    //private CustomerService() {}

    public static CustomerService getInstance() {
        if (null == customerService) {
            System.out.println(" ");
            System.out.println("Welcome to Capital Hotel Reservation Services");
            customerService = new CustomerService();
        }

        return customerService;
    }

    //private static List<Customers> customersList = new ArrayList<Customers>();

    public  void addCustomers(Customers customers) {
        customersList.add(customers);
        System.out.println("add" + customersList);
    }

    /*public void addCustomers(String email, String firstName, String middleName, String lastName) {
        try {
            customersList.add(new Customers(firstName, middleName, lastName, email));
        } catch (IllegalArgumentException exception) {
            exception.getLocalizedMessage();
        }
        Customers customers = new Customers(firstName, middleName, lastName, email);
        customers.add(customers);
    }*/

    public Customers getCustomers(String customersEmail) {
        try {
            for (int i = 0; i < customersList.size(); i++) {
                if (customersList.get(i).getEmail() == customersEmail) {
                    return customersList.get(i);
                }
            }
        } catch (ArrayIndexOutOfBoundsException exception) {
            System.out.println("This email does not exist, please try again");
        }

            return null;
    }

    public Collection<Customers> getAllCustomers() {
        return customersList;
    }
}
