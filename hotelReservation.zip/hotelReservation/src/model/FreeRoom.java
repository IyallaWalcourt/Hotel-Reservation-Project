package model;

public class FreeRoom extends Rooms {

    public FreeRoom(String roomNumber, RoomType enumeration) {
        super(roomNumber, enumeration);

        this.roomPrice = 0.0;
    }

    @Override
    public String toString(){
        return "This room is Free";
    }
}
