package service;

import model.Customers;

import java.util.*;

public class CustomerService {

    private static CustomerService customerService = null;

    private static  ArrayList<Customers> customersList = new ArrayList<>();


    public static CustomerService getInstance() {
        if (null == customerService) {
            System.out.println(" ");
            System.out.println("Welcome to Capital Hotel Reservation Services");
            customerService = new CustomerService();
        }

        return customerService;
    }

    public void addCustomers(String firstName, String middleName, String lastName, String email) {
        /*try {
            customersList.add(new Customers(firstName, middleName, lastName, email));
        } catch (IllegalArgumentException exception) {
            exception.getLocalizedMessage();
        }*/
        Customers customers = new Customers(firstName, middleName, lastName, email);
        customersList.add(customers);
    }

    public Customers getCustomers(String customersEmail) {

        for (Customers compareCustomers : customersList) {
            if (customersEmail.equals(compareCustomers.getEmail())) {
                return compareCustomers;
            }
        }
        System.out.println("This email does not exist, please try again");

        return null;
    }

    /*public Customers getCustomers(String customersEmail) {
        try {
            for (int i = 0; i < customersList.size(); i++) {
                if (customersList.get(i).getEmail() == customersEmail) {
                    return customersList.get(i);
                }
            }
        } catch (ArrayIndexOutOfBoundsException exception) {
            System.out.println("This email does not exist, please try again");
        }

        return null;
    }*/

    public Collection<Customers> getAllCustomers() {
        return customersList;
    }
}
