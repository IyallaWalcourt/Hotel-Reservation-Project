package service;

import model.Customers;
import model.IRoom;
import model.Reservation;

import java.util.*;

public class ReservationService {

    public static List <IRoom> roomList = new ArrayList<>();
    public static List <Reservation> reservationList = new ArrayList<>();

    public void addRoom (IRoom room) {

        roomList.add(room);
}

    public  IRoom getARoom (String roomId) {

        for (int i = 0; i < roomList.size(); i++) {
            try{
                if (roomList.get(i).getRoomNumber() == roomId){
                    return roomList.get(i);
                }
            } catch (ArrayIndexOutOfBoundsException exception) {
                System.out.println("there is no room with number %s, choose another one%n\", roomId");
            }
        }

        return null;
}

    public Reservation reserveRoom (Customers customers, IRoom rooms, Date checkInDate, Date checkOutDate){

        Reservation reserve = new Reservation(customers, rooms, checkInDate, checkOutDate);
        reservationList.add (reserve);
        return reserve;
    }

    public Collection <IRoom> findRoom(Date checkInDate, Date checkOutDate) {
        List <IRoom> reserved = new ArrayList<>();
        for (IRoom roomSpace : roomList) {
            for (Reservation revSpace : reservationList) {
                if ( checkInDate.after ( revSpace.getCheckOutDate ( ) ) || checkOutDate.before ( revSpace.getCheckInDate ( ) ) ) {
                    reserved.add ( roomSpace );
                }
            }
        }
        return reserved;
            }

            public Collection <Reservation> getCustomersReservations (Customers customers) {

        ArrayList <Reservation> resArray = new ArrayList<>();
            for (Reservation revSpace : reservationList) {
                if(revSpace.getCustomers() == customers) {
                    resArray.add(revSpace);
                }
            }
            return resArray;
        }

        public void printAllReservations () {
        for (Reservation reserve : reservationList) {
            System.out.println(reserve);
        }
    }
}





