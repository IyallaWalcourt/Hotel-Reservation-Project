//import static menus.MainMenu.displayMainMenu;
import static menus.MainMenu.mainMenu;

public class HotelApplication {

    public static void main ( String [ ] args ) {

        mainMenu();
    }
}
