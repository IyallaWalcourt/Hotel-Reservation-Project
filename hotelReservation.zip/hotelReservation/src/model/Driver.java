package model;

public class Driver {

    public static void main(String[] args) {
        Customers customers = new Customers("Iyalla", "Dokiwari", "Walcourt",
                "iyalla@gmail.com");

        Rooms freeRoom = new FreeRoom("10", RoomType.SINGLE);

        System.out.println(customers);
        System.out.println(freeRoom);

    }
}
