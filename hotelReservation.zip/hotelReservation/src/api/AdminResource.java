package api;

import model.Customers;
import model.IRoom;
import model.RoomType;
import model.Rooms;
import service.CustomerService;
import service.ReservationService;

import java.util.Collection;
import java.util.List;

public class AdminResource {


    private static final ReservationService reservationservice = ReservationService.getInstance();

    public static CustomerService customerservice = CustomerService.getInstance();

    public Customers getCustomers (String email) {
        return customerservice.getCustomers (email);
    }

    public void  addRoom (List <IRoom> rooms){
        for (IRoom room : rooms) {
            reservationservice.addRoom(room);
        }
    }

    public void  makeRoom (String roomNumber, double roomprice, RoomType enumeration) {
        IRoom temp = new Rooms(roomNumber, roomprice, enumeration);
        reservationservice.addRoom(temp);
    }

    public Collection<IRoom> getAllRooms(){
        return reservationservice.getAllRooms();
    }

    public Collection <Customers> getAllCustomers () {
        return customerservice.getAllCustomers();
    }

    public  void displayAllReservations () {
        reservationservice.printAllReservation();
    }
}
