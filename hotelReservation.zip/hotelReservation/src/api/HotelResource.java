package api;

import model.Customers;
import model.IRoom;
import model.Reservation;
import service.CustomerService;
import service.ReservationService;

import java.util.Collection;
import java.util.Date;

public class HotelResource {

    public static ReservationService reservationservice = new ReservationService();
    //public static  HotelResource hotelresource = new HotelResource();
    public static CustomerService customerservice = CustomerService.getInstance();

    public Customers getCustomers (String email) {
        return customerservice.getCustomers (email);
    }

    public void createAcustomer (String firstName, String middleName, String lastName, String email) {

        try {
            customerservice.addCustomers(new Customers(firstName, middleName, lastName, email));
            //customerservice.addCustomers(firstName, middleName, lastName, email);
        } catch (IllegalArgumentException exception) {
            exception.getLocalizedMessage();
        }
    }

    public IRoom getRoom (String roomNumber){

        return reservationservice.getARoom(roomNumber);
    }

    public Reservation bookARoom (String customerEmail, IRoom room, Date checkInDate, Date checkOutDate) {

        Customers customerservice = getCustomers(customerEmail);

        if (customerservice != null) {
            return reservationservice.reserveRoom(customerservice, room, checkInDate, checkOutDate);
        }

        else {
            System.out.println("No customer with this email address");
        }

        return null;

        //return reservationservice.reserveRoom (getCustomers (customerEmail), room, checkInDate, checkOutDate);
    }


    public Collection <Reservation> getCustomersReservations (String customerEmail) {

        return reservationservice.getCustomersReservations(getCustomers (customerEmail));
    }

    public  Collection <IRoom> findARoom(Date checkIn, Date checkOut) {

        return reservationservice.findRooms(checkIn, checkOut);
    }


}
