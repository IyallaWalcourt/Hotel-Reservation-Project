package menus;

import api.HotelResource;
import model.Customers;
import model.IRoom;
import model.Reservation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.Scanner;

public class MainMenu {

    private static final HotelResource hotelresource = new HotelResource();

    public static void mainMenu() {


        boolean keepRunning = true;
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please choose an option between 1-5 below and press ENTER. Thank you");
        System.out.println("=============================================================================");
        System.out.println("1. Find and Reserve a Room");
        System.out.println("2. See my Reservations");
        System.out.println("3. Create an account");
        System.out.println("4. Admin");
        System.out.println("5. Exit");
        while(keepRunning) {
            try {
                int selection = Integer.parseInt(scanner.nextLine());

                switch(selection) {
                    case(1):
                        findAndReserveRoom();
                        mainMenuCalling();
                        keepRunning = false;

                    case(2):
                        seeMyReservations();
                        mainMenu();
                        keepRunning = false;

                    case(3):
                        createAccount();
                        mainMenu();
                        keepRunning = false;

                    case(4):
                        AdminMenu.displayAdminMenu();
                        keepRunning = false;

                    case(5):
                        System.out.println("Exit");
                        keepRunning = false;
                        break;
                    default:
                        System.out.println("Select Valid Option");
                }

            }catch (Exception ex) {
                System.out.println(ex.getLocalizedMessage());
            }
        }
    }


    public static void findAndReserveRoom() {
        Date checkIn = new Date ();
        Date checkOut = new Date ();
        Date currentDate = new  Date();

        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
        //Scanner opening
        Scanner scanner = new Scanner(System.in);


        //check to see if CheckInDate correct or not
        Boolean incurrectCheckInDate = true;

        while (incurrectCheckInDate) {
            System.out.println("Please reserve a room: "
                    + "\nEnter CHECK-IN date using this format: MM/DD/YYYY"
                    + "\neg: 01/19/2022");
            String checkInString = scanner.next();

            //date conversion
            try {
                try {
                    checkIn = formatter.parse(checkInString);
                }
                catch(Exception e){
                    throw new IllegalArgumentException("Wrong! CHECK-IN date format. Please re-type");
                }

                //Making sure CHECK-IN date is not in the past
                if (checkIn.before(currentDate)) {
                    throw new IllegalArgumentException("Your CHECK-IN date cannot be in the past");
                }
                incurrectCheckInDate = false;

            } catch (Exception e) {
                System.out.println(e.getLocalizedMessage());
            }

        }

        //check to see if CheckOutDate is correct or not
        Boolean incurrectCheckOutDate = true;
        while (incurrectCheckOutDate) {
            System.out.println("Enter your CHECK-OUT date using this format: MM/DD/YYYY"
                    + "\neg: 01/19/2022");
            String checkOutString = scanner.next();
            try{
                try {
                    checkOut = formatter.parse(checkOutString);
                }
                catch(Exception e){
                    throw new IllegalArgumentException("Wrong! CHECK-OUT date format. Please re-type.");
                }

                //Making sure CHECK-OUT date is not in the past
                if ((checkOut.before(currentDate)) || (checkOut.before(checkIn))){
                    throw new IllegalArgumentException("Your CHECK-OUT date cannot be in the past");
                }
                incurrectCheckOutDate = false;
            } catch (Exception e) {
                System.out.println(e.getLocalizedMessage());
            }
        }


        Collection<IRoom> availableRooms = hotelresource.findARoom(checkIn, checkOut);
        System.out.println(availableRooms);
        if (availableRooms.isEmpty()) {

            final Date altCheckIn = hotelresource.addRecommendedDays(checkIn);
            final Date altCheckOut = hotelresource.addRecommendedDays(checkOut);
            Collection<IRoom> recommendedRooms = hotelresource.findRecommendedRooms(checkIn, checkOut);
            if (recommendedRooms.isEmpty()) {

                System.out.println("Recommended Rooms not available if date is more than 7 days.");
            } else {
                System.out.println("No available rooms for these dates. See Recommended Rooms: CheckIn date of " + altCheckIn + " on CheckOut date of " + altCheckOut);

                System.out.println(recommendedRooms);
                reserveRoom(scanner, altCheckIn, altCheckOut, recommendedRooms);
            }
        }else {
            reserveRoom(scanner, checkIn, checkOut, availableRooms);

            mainMenuCalling();
        }


    }

    public static void reserveRoom(Scanner scanner, Date checkInDate, Date checkOutDate, Collection<IRoom> rooms) {

        System.out.println("Will you like to book a room? y/n ");
        String book = scanner.nextLine();

        if ("y".equals(book)) {
            System.out.println("Do yo have an account? y/n");
            String account = scanner.nextLine();

            if ("y".equals(account)) {
                System.out.println("Enter Email: ");
                String email = scanner.nextLine();

                if (hotelresource.getCustomers(email) == null) {
                    System.out.println("Customer not found. \n Create New Account..");
                    createAccount();
                } else {
                    System.out.println("Enter the room number that you want to book: ");
                    String roomNum = scanner.nextLine();

                    if (rooms.stream().anyMatch(room -> room.getRoomNumber().equals(roomNum))) {
                        final IRoom room = hotelresource.getRoom(roomNum);
                        final Reservation reservation = hotelresource.bookARoom(email, room, checkInDate, checkOutDate);
                        System.out.println("Reservation Created");
                        System.out.println(reservation);
                    } else {
                        System.out.println("Error: Room number not available.\nSTART AGAIN..");
                    }

                }
            } else if("n".equals(account)) {
                System.out.println("Create Account ");
                createAccount();
                mainMenu();
            }
        } else {
            mainMenuCalling();

        }
    }

    public static void seeMyReservations() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter email:");
        String email = scanner.nextLine();

        System.out.println(hotelresource.getCustomersReservations(email));

        mainMenuCalling();
    }

    public static void createAccount() {

        Scanner scanner = new Scanner (System.in);

        System.out.println("Please Enter your Firstname:");
        String firstName = scanner.nextLine();

        System.out.println("Enter your Middle Name:");
        String middleName = scanner.nextLine();

        System.out.println("Enter your lastName");
        String lastName = scanner.nextLine();

        System.out.println("Enter email: ");
        String email = scanner.nextLine();

        try {
            hotelresource.createACustomer(firstName, middleName, lastName, email);
            System.out.println("Your Account has benn created");

        } catch (IllegalArgumentException ex) {
            System.out.println(ex.getLocalizedMessage());
        }
        //mainMenuCalling();
    }

    public static void mainMenuCalling() {
        System.out.println("Continue? y/n");

        Scanner scanner = new Scanner(System.in);
        String response = scanner.nextLine();
        boolean run = true;

        while (run) {
            if ("y".equals(response)) {
                mainMenu();
            } else if ("n".equals(response)) {
                System.out.println("Exit");
                run = false;
            }
        }
    }

}
