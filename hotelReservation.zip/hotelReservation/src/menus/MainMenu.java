package menus;

import api.HotelResource;
import model.Customers;
import model.IRoom;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class MainMenu {

    private static final HotelResource hotelresource = new HotelResource();
    private static final AdminMenu adminmenu = new AdminMenu();

    public  static void displayMainMenu() {

        Scanner scanner = new Scanner(System.in);
        int userInput = 0;

        while (userInput != 5) {

            printOptions ();
            userInput = scanner.nextInt();

            switch (userInput) {
                case 1 :
                    case1 ();
                    break;
               case 2 :
                    case2 ();
                    break;
               case 3 :
                    try {
                        case3 ();
                    } catch (IllegalArgumentException exception) {
                        exception.getLocalizedMessage();
                   System.out.println (exception.getLocalizedMessage());
                        System.out.println("Please re-enter your email with the correct format: e.g name@yourdomaim.com");
                        String email = scanner.next();
                    }
                    break;
              case 4 :
                    adminmenu.displayAdminMenu();
					break;

            }
        }

        System.out.println ("You have exited the application..."
                + "\nThanks and Good by");

    }

    public static void printOptions () {

        System.out.println("Please choose an option between 1-5 below and press ENTER. Thank you");
        System.out.println("=============================================================================");
        System.out.println("Main Menu ");
        System.out.println("--------- ");

        System.out.println ("1. Find and reserve a room"
                + "\n2. See my reservations"
                + "\n3. Create an account"
                + "\n4. Admin"
                + "\n5. Exit");

        System.out.println("=============================================================================");
    }

    //Find and reserved room
    public static void case1 () {
        Date checkIn = new Date ();
        Date checkOut = new Date ();
        SimpleDateFormat format = new SimpleDateFormat ("MM/dd/yyyy");

        System.out.println ("Please reserve a room: "
                + "\nEnter CHECK-IN date using this format: MM/DD/YYYY"
                + "\neg: 01/19/2022");

        Scanner scanner = new Scanner (System.in);
        String checkInInput = scanner.next ();

        try {
            checkIn = format.parse (checkInInput);
        } catch (ParseException exception) {
            exception.printStackTrace ();
        }

        System.out.println ("Enter CHECK-OUT date using this format: MM/DD/YYYY"
                + "\neg: 01/19/2022");
        String checkOutInput = scanner.next ();
        try {
            checkOut = format.parse (checkOutInput);
        } catch (ParseException exception) {
            exception.printStackTrace ();
        }

        System.out.println ("Available Rooms: "
                + "\n" + hotelresource.findARoom (checkIn, checkOut)
                + "\n Enter a Room Number");
        String bookingNow = scanner.next ();
        IRoom room = hotelresource.getRoom (bookingNow);
        System.out.println (room
                + " " + bookingNow
                + "\nEnter your email: ");
        String email = scanner.next ();
        hotelresource.bookARoom (email, room, checkIn, checkOut);
        System.out.println (email + " " + room + " " + checkIn + " " + checkOut
                + "\n CONGRATS!, Your Room is booked" );
        System.out.println(" ");
    }

    //view Reservations
    public static void case2 () {

        Scanner scanner = new Scanner (System.in);
        System.out.println ("View your reservation: "
                + "\n Please enter your email address: ");
        String email = scanner.next ();
        System.out.println (hotelresource.getCustomersReservations (email));
        System.out.println(" ");
    }

    //Create an Account
    public static Customers case3() {

        Scanner scanner = new Scanner (System.in);
            System.out.println("Please enter your First Name: ");
            String firstName = scanner.next();
            System.out.println("Enter your Middle Name: ");
            String middleName = scanner.next();
            System.out.println("Enter your Last Name: ");
            String lastName = scanner.next();
            System.out.println("Enter your email: e.g name@yourdomaim.com");
            String email = scanner.next();
            System.out.println("Cool");
            Customers customers = new Customers(firstName, middleName, lastName, email);
            hotelresource.createAcustomer(customers);
            //hotelresource.createAcustomer(firstName, middleName, lastName, email);
            return customers;
            //System.out.println(" ");
            //return new Customers(firstName, middleName, lastName, email);

       }

    }
