package model;

import java.util.Date;

public class Reservation {

    private Customers customers;
    private IRoom rooms;
    private Date checkInDate;
    private Date checkOutDate;

    public Reservation(Customers customers, IRoom rooms, Date checkInDate, Date checkOutDate) {
        this.customers = customers;
        this.rooms = rooms;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
    }

    public void setCustomers(Customers customers) {
        this.customers = customers;
    }

    public void setRooms(IRoom rooms) {
        this.rooms = rooms;
    }

    public void setCheckInDate(Date checkInDate) {
        this.checkInDate = checkInDate;
    }

    public void setCheckOutDate(Date checkOutDate) {
        this.checkOutDate = checkOutDate;
    }


    public Customers getCustomers() {
        return customers;
    }

    public IRoom getRooms() {
        return rooms;
    }

    public Date getCheckInDate() {
        return checkInDate;
    }

    public Date getCheckOutDate() {
        return checkOutDate;
    }

    @Override
    public String toString() {
        return " Customers: " + customers + " Rooms: " + rooms + " Check in date: " + checkInDate +
                " Check out date: " + checkOutDate;
    }

    public IRoom getRoom() {
        return rooms;
    }
}
