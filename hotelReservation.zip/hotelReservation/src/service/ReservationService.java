package service;

import model.Customers;
import model.IRoom;
import model.Reservation;

import java.util.*;

public class ReservationService {

    public static List <IRoom> reserved = new ArrayList<>();
    public static List <Reservation> reservationList = new ArrayList<>();

    public void addRoom (IRoom room) {

        reserved.add(room);
}

    public  IRoom getARoom (String roomId) {

        for (int i = 0; i < reserved.size(); i++) {
            try{
                if (reserved.get(i).getRoomNumber() == roomId){
                    return reserved.get(i);
                }
            } catch (ArrayIndexOutOfBoundsException exception) {
                System.out.println("Room does not exist, please choose another room number");
            }
        }

        return null;
}

    public Reservation reserveRoom (Customers customers, IRoom rooms, Date checkInDate, Date checkOutDate){

        Reservation reserve = new Reservation(customers, rooms, checkInDate, checkOutDate);
        reservationList.add (reserve);
        return reserve;
    }

    public Collection <IRoom> findRoom(Date checkInDate, Date checkOutDate) {
        List <IRoom> reserved = new ArrayList<>();
        for (IRoom roomSpace : ReservationService.reserved) {
            for (Reservation revSpace : reservationList) {
                if (checkInDate.after(revSpace.getCheckInDate()) && checkInDate.before(revSpace.getCheckOutDate()) ||
                        (checkOutDate.after(revSpace.getCheckInDate()) && checkOutDate.before(revSpace.getCheckOutDate())) ||
                        (checkInDate.equals(revSpace.getCheckInDate()))||
                        (checkOutDate.equals(revSpace.getCheckOutDate()))) {
                    reserved.add (roomSpace);
                }
            }
        }
        return reserved;
            }

    //if (checkInDate.after (revSpace.getCheckOutDate ()) || checkOutDate.before
    //(revSpace.getCheckInDate ()))

            public Collection <Reservation> getCustomersReservations (Customers customers) {

        ArrayList <Reservation> resArray = new ArrayList<>();
            for (Reservation revSpace : reservationList) {
                if(revSpace.getCustomers() == customers) {
                    resArray.add(revSpace);
                }
            }
            return resArray;
        }

        public void printAllReservations () {
        for (Reservation reserve : reservationList) {
            System.out.println(reserve);
        }
    }
}





