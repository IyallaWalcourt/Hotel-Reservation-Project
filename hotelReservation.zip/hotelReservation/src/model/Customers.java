package model;

import java.util.regex.Pattern;

public class Customers {

    private String firstName;
    private String middleName;
    private String lastName;
    private String email;

    private final String emailRegex = "^(.+)@(.+).com$";
    private final Pattern pattern = Pattern.compile(emailRegex);

    public Customers(String firstName, String middleName, String lastName, String email) {
        if (!pattern.matcher(email).matches()) {

            this.firstName = firstName;
            this.middleName = middleName;
            this.lastName = lastName;
            this.email = email;
        } else
            throw new IllegalArgumentException("Error, Invalid email address");

        System.out.println ( "Cool" );

        }


    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setEmail(String email) {
        this.email = email;
    }


    public String getFirstName() {
        return firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getEmail() {
        return email;
    }

    @Override
    public String toString() {
        return "First Name: " + firstName + " " + "Middle Name: " + middleName + " " + "Last Name: " + lastName
                 + " " + "Email: " + email;
    }
    //add method that will be called in CustomerService class
    public void add(Customers customers) {
    }

}
