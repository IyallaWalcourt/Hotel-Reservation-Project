package api;

import model.Customers;
import model.IRoom;
import model.Reservation;
import service.CustomerService;
import service.ReservationService;

import java.util.Collection;
import java.util.Date;

import static service.ReservationService.reservationService;

public class HotelResource {



    private static final ReservationService reservationservice = ReservationService.getInstance();

    public static CustomerService customerservice = CustomerService.getInstance();

    public Customers getCustomers (String email) {
        return customerservice.getCustomers (email);
    }

    /*public void createAcustomer (String firstName, String middleName, String lastName, String email) {

        try {
            customerservice.addCustomers(firstName, middleName, lastName, email);
        } catch (IllegalArgumentException exception) {
            exception.getLocalizedMessage();
        }
    }*/

    /*public void createACustomer(String email, String firstName, String lastName) {
        customerservice.addCustomers(email, firstName, lastName);
    }*/

    public void createACustomer(String firstName, String middleName, String lastName, String email) {
        customerservice.addCustomers(firstName, middleName, lastName, email);
    }

    public static IRoom getRoom (String roomNumber){

        return reservationservice.getARoom(roomNumber);
    }

    public Reservation bookARoom (String customerEmail, IRoom room, Date checkInDate, Date checkOutDate) {

        Customers customers = CustomerService.getInstance().getCustomers(customerEmail);

        if (customerservice != null) {
            return reservationservice.reserveARoom(customers, room, checkInDate, checkOutDate);
        }

        else {
            System.out.println("No customer with this email address");
        }

        return null;

    }


    public Collection <Reservation> getCustomersReservations (String customerEmail) {

        return reservationservice.getCustomersReservation(getCustomers (customerEmail));
    }

    public  Collection <IRoom> findARoom(Date checkIn, Date checkOut) {

        return reservationservice.findRooms(checkIn, checkOut);
    }

    public Collection<IRoom> findRecommendedRooms(final Date checkIn, final Date checkOut) {

        return reservationService.findRecommendedRooms(checkIn, checkOut);
    }

    public Date addRecommendedDays(final Date date) {
        return reservationService.addRecommendedDays(date);
    }

}

